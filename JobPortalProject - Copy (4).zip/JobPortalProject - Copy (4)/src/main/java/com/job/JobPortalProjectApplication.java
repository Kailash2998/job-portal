package com.job;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobPortalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobPortalProjectApplication.class, args);
	}

}
